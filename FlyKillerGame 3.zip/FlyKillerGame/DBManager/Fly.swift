//
//  Fly.swift
//  FlyKillerGame
//
//  Created by Naeem Abbas on 12/01/2024.
//

import Foundation
struct Fly{
    
    var name : String
    var price : String
    var score : String
 
}
