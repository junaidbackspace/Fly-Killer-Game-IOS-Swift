//
//  GameLevelViewController.swift
//  FlyKillerGame
//
//  Created by Naeem Abbas on 10/01/2024.
//

import UIKit

class GameLevelViewController: UIViewController {
   

 
    var levelCompletionStatus: [Int: Bool] = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Assume all levels are initially locked except for the first one
               for levelNumber in 1...12 {
                   levelCompletionStatus[levelNumber] = (levelNumber == 1) // true for level 1, false for others
               }
       
    }
func canAccessLevel(_ levelNumber: Int) -> Bool {
        if let completed = levelCompletionStatus[levelNumber - 1] {
            return completed // Allow access if the previous level is completed
        }
        return false // Default to not allowing access if previous level completion status is unknown
    }
    @IBAction func btn1(_ sender: Any) {
        
//        if canAccessLevel(1) {
//                    startGame(levelNumber: 1)
//                } else {
//                    print("You must complete the previous level before accessing this one.")
//                }
     
       
       let Start = storyboard?.instantiateViewController(identifier: "GamePlayViewController") as! GamePlayViewController
        Start.modalPresentationStyle = .fullScreen
               present(Start, animated: true)
    }

    @IBAction func btn2(_ sender: Any) {
//        let Start = storyboard?.instantiateViewController(identifier: "GamePlayViewController") as! GamePlayViewController
//        Start.modalPresentationStyle = .fullScreen
//               present(Start, animated: true)
        if canAccessLevel(2) {
                    startGame(levelNumber: 2)
                } else {
                    print("You must complete the previous level before accessing this one.")
                }
    }
    @IBAction func btn3(_ sender: Any) {
        let Start = storyboard?.instantiateViewController(identifier: "GamePlayViewController") as! GamePlayViewController
        Start.modalPresentationStyle = .fullScreen
               present(Start, animated: true)
    }
    @IBAction func btn4(_ sender: Any) {
        let Start = storyboard?.instantiateViewController(identifier: "GamePlayViewController") as! GamePlayViewController
        Start.modalPresentationStyle = .fullScreen
               present(Start, animated: true)
    }
    @IBAction func btn5(_ sender: Any) {
        let Start = storyboard?.instantiateViewController(identifier: "GamePlayViewController") as! GamePlayViewController
        Start.modalPresentationStyle = .fullScreen
               present(Start, animated: true)
    }
    @IBAction func btn6(_ sender: Any) {
        let Start = storyboard?.instantiateViewController(identifier: "GamePlayViewController") as! GamePlayViewController
        Start.modalPresentationStyle = .fullScreen
               present(Start, animated: true)
    }
    
     @IBAction func btn7(_ sender: Any) {
         let Start = storyboard?.instantiateViewController(identifier: "GamePlayViewController") as! GamePlayViewController
         Start.modalPresentationStyle = .fullScreen
                present(Start, animated: true)
     }
 
   
    @IBAction func btnlevel8(_ sender: Any) {
        let Start = storyboard?.instantiateViewController(identifier: "GamePlayViewController") as! GamePlayViewController
        Start.modalPresentationStyle = .fullScreen
               present(Start, animated: true)
    }
    
    @IBAction func btnlevel9(_ sender: Any) {
        let Start = storyboard?.instantiateViewController(identifier: "GamePlayViewController") as! GamePlayViewController
        Start.modalPresentationStyle = .fullScreen
               present(Start, animated: true)
    }
    @IBAction func btnlevel10(_ sender: Any) {
        let Start = storyboard?.instantiateViewController(identifier: "GamePlayViewController") as! GamePlayViewController
        Start.modalPresentationStyle = .fullScreen
               present(Start, animated: true)
    }
    
    @IBAction func btnlevel11(_ sender: Any) {
        let Start = storyboard?.instantiateViewController(identifier: "GamePlayViewController") as! GamePlayViewController
        Start.modalPresentationStyle = .fullScreen
               present(Start, animated: true)
    }
    
    @IBAction func btnlevel12(_ sender: Any) {
        let Start = storyboard?.instantiateViewController(identifier: "GamePlayViewController") as! GamePlayViewController
        Start.modalPresentationStyle = .fullScreen
               present(Start, animated: true)
    }
    func startGame(levelNumber: Int) {
           // Start the game with the specified level
           let gamePlayViewController = storyboard?.instantiateViewController(identifier: "GamePlayViewController") as! GamePlayViewController
           gamePlayViewController.level = levelNumber
           gamePlayViewController.modalPresentationStyle = .fullScreen
           present(gamePlayViewController, animated: true)
       }
    /*
     // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    
    
    @IBAction func btnHome(_ sender: Any) {
        let Start = storyboard?.instantiateViewController(identifier: "FirstViewController") as! FirstViewController
        Start.modalPresentationStyle = .fullScreen
               present(Start, animated: true)
        
    }
     
    @IBAction func btnshop(_ sender: Any) {
        let Start = storyboard?.instantiateViewController(identifier: "ShopViewController") as! ShopViewController
        Start.modalPresentationStyle = .fullScreen
               present(Start, animated: true)
    }
}
