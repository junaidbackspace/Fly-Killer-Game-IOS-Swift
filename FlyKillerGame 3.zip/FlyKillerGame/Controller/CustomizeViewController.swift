//
//  CustomizeViewController.swift
//  FlyKillerGame
//
//  Created by Naeem Abbas on 11/01/2024.
//

import UIKit
import DropDown
class CustomizeViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate {
    
    //var isChecked = false // checkbox Default unchecked state

    let checkboxButton = UIButton()
    
    @IBOutlet weak var numberTextField: UITextField!
    
    var flyImageView: UIImageView!
    let options = ["2x", "3x", "4x"] // Dropdown options
    var tableView = UITableView()
      var textField = UITextField()
    
    let option1 = ["2x", "3x", "4x"] // Dropdown options
    var tableView1 = UITableView()
      var textField1 = UITextField()
    
    let option3 = ["2x", "3x", "4x"] // Dropdown options
    var tableView3 = UITableView()
      var textField3 = UITextField()
    
    
    
    //dropdown lbl hy four dropdown and create 4 lbl
 
    var checkBoxSwitch: UISwitch!
       var checkBoxButton: UIButton!
   var isChecked: Bool = false
    var checkBoxSwitch2: UISwitch!
       var checkBoxButton2: UIButton!
    var isChecked2: Bool = false
    var checkBoxSwitch3: UISwitch!
       var checkBoxButton3: UIButton!
    var isChecked3: Bool = false
    var checkBoxSwitch4: UISwitch!
       var checkBoxButton4: UIButton!
    var isChecked4: Bool = false
    
    let home = UIButton(type: .system)
    let back = UIButton(type: .system)
    
    let drp = DropDown()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //textfield set score
       // numberTextField.delegate = self
        //checkbox1 Set initial state
              checkboxButton.frame = CGRect(x: 100, y: 100, width: 200, height: 100) // Adjust size and position as needed
              checkboxButton.addTarget(self, action: #selector(checkboxTapped), for: .touchUpInside)
              updateCheckboxImage()
              self.view.addSubview(checkboxButton)
        
 //switch one dropdown wala
        checkBoxSwitch = UISwitch(frame:CGRect(x: 350, y: 280, width: 30, height: 30))
               checkBoxSwitch.isOn = false // Initial state
               checkBoxSwitch.onTintColor = UIColor.blue // Background color when switch is ON
               checkBoxSwitch.addTarget(self, action: #selector(switchChanged), for: .valueChanged)
               self.view.addSubview(checkBoxSwitch)
        
        //switch one
               checkBoxSwitch2 = UISwitch(frame:CGRect(x: 350, y: 420, width: 30, height: 30))
                      checkBoxSwitch2.isOn = false // Initial state
                      checkBoxSwitch2.onTintColor = UIColor.blue // Background color when switch is ON
                      checkBoxSwitch2.addTarget(self, action: #selector(switchChanged2), for: .valueChanged)
                      self.view.addSubview(checkBoxSwitch2)
        //switch three
               checkBoxSwitch3 = UISwitch(frame:CGRect(x: 350, y: 570, width: 30, height: 30))
                      checkBoxSwitch3.isOn = false // Initial state
                      checkBoxSwitch3.onTintColor = UIColor.blue // Background color when switch is ON
                      checkBoxSwitch3.addTarget(self, action: #selector(switchChanged3), for: .valueChanged)
                      self.view.addSubview(checkBoxSwitch3)
               
               //switch four
                      checkBoxSwitch4 = UISwitch(frame:CGRect(x: 350, y: 730, width: 30, height: 30))
                             checkBoxSwitch4.isOn = false // Initial state
                             checkBoxSwitch4.onTintColor = UIColor.blue // Background color when switch is ON
                             checkBoxSwitch4.addTarget(self, action: #selector(switchChanged4), for: .valueChanged)
                             self.view.addSubview(checkBoxSwitch4)
    
 
        
        
}
    // textfield set score
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
         // Check if the replacement string contains only integer values
         let allowedCharacterSet = CharacterSet(charactersIn: "0123456789")
         let replacementStringCharacterSet = CharacterSet(charactersIn: string)
         let isOnlyInteger = allowedCharacterSet.isSuperset(of: replacementStringCharacterSet)

         // Return true only if the replacement string contains only integer values
         return isOnlyInteger
     }
    
    // checkbox tapped function
    @objc func checkboxTapped() {
           isChecked = !isChecked // Toggle isChecked state
           updateCheckboxImage()
           
           // Perform action based on isChecked state
           if isChecked {
               print("Checkbox is checked")
               // Perform any action when checkbox is checked
           } else {
               print("Checkbox is unchecked")
               // Perform any action when checkbox is unchecked
           }
       }

       func updateCheckboxImage() {
           let imageName = isChecked ? "checked_circle" : "unchecked_circle"
           checkboxButton.setImage(UIImage(named: imageName), for: .normal)
       }
    
    // UISwitch value changed one
    @objc func switchChanged(mySwitch: UISwitch) {
           if mySwitch.isOn {
               print("Switch is ON")
           } else {
               print("Switch is OFF")
           }
       }
    
    // UISwitch value changed two
    @objc func switchChanged2(mySwitch: UISwitch) {
           if mySwitch.isOn {
               print("Switch is ON")
           } else {
               print("Switch is OFF")
           }
       }
    @objc func switchChanged3(mySwitch: UISwitch) {
           if mySwitch.isOn {
               print("Switch is ON")
           } else {
               print("Switch is OFF")
           }
       }
    
    // UISwitch value changed two
    @objc func switchChanged4(mySwitch: UISwitch) {
           if mySwitch.isOn {
               print("Switch is ON")
           } else {
               print("Switch is OFF")
           }
       }
       
    // MARK: - Table view data source and delegate methods
        
    @objc func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return options.count
        }
        
    @objc(tableView:cellForRowAtIndexPath:) func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
            cell.textLabel?.text = options[indexPath.row]
        
            return cell
        }
        
        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            textField.text = options[indexPath.row]
            tableView.isHidden = true
        }
        
        // MARK: - Text field action
        
        @objc func textFieldTapped() {
            tableView.isHidden = !tableView.isHidden
        }
    // MARK: - Table view data source and delegate methods2
        
    @objc func tableView1(_ tableView2: UITableView, numberOfRowsInSection section: Int) -> Int {
            return option1.count
        }
        
    @objc(tableView:cellForRowAtIndexPath2:) func tableView(_ tableView2: UITableView, cellForRowAt1 indexPath: IndexPath) -> UITableViewCell {
            let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
            cell.textLabel?.text = option1[indexPath.row]
            return cell
        }
        
        func tableView1(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            textField1.text = option1[indexPath.row]
            tableView.isHidden = true
        }
        
        // MARK: - Text field action
        
        @objc func textFieldTapped2() {
            tableView1.isHidden = !tableView1.isHidden
        }
    // MARK: - Table view data source and delegate methods3
        
    @objc func tableView3(_ tableView2: UITableView, numberOfRowsInSection section: Int) -> Int {
            return option3.count
        }
        
    @objc(tableView:cellForRowAtIndexPath3:) func tableView3(_ tableView3: UITableView, cellForRowAt3 indexPath: IndexPath) -> UITableViewCell {
            let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
            cell.textLabel?.text = option3[indexPath.row]
            return cell
        }
        
        func tableView3(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            textField3.text = option3[indexPath.row]
            tableView.isHidden = true
        }
        
        // MARK: - Text field action
        
        @objc func textFieldTapped3() {
            tableView3.isHidden = !tableView3.isHidden
        }
    //home tapped function
    @objc func HomeButtonTapped() {
        print("")
        let Start = storyboard?.instantiateViewController(identifier: "FirstViewController") as!  FirstViewController
        Start.modalPresentationStyle = .fullScreen
               present(Start, animated: true)
    }
    //back image tapped function
     
    @objc func BackButtonTapped() {
        print("")
        let Start = storyboard?.instantiateViewController(identifier: "GamePlayViewController") as!  GamePlayViewController 
        Start.modalPresentationStyle = .fullScreen
               present(Start, animated: true)
    }
       // UIButton tapped
//       @objc func buttonTapped(sender: UIButton) {
//           sender.isSelected = !sender.isSelected // Toggle button state
//
//           if sender.isSelected {
//               checkBoxButton.backgroundColor = UIColor.blue
//               print("Button is selected")
//           } else {
//
//               print("Button is deselected")
//           }
//       }
 
        
        @IBAction func playButtonTapped(_ sender: UIButton) {
            guard let image = selectedImage else {
                // Show an alert indicating that no image has been selected
                return
            }
       
//            
//            let storyboard = UIStoryboard(name: "GamePlayViewController ", bundle: nil)
//            if let GamePlayViewController = storyboard.instantiateViewController(withIdentifier: "GamePlayViewController") as? GamePlayViewController {
//                GamePlayViewController.selectedImage = image
//                navigationController?.pushViewController(GamePlayViewController, animated: true)
//            }
        }
      
    var selectedImage: UIImage?
    // create dropdown button action
    
    // create back first view controller  Action
    
    
    @IBAction func btnaction(_ sender: Any) {
        let Start = storyboard?.instantiateViewController(identifier: "FirstViewController") as! FirstViewController
        Start.modalPresentationStyle = .fullScreen
               present(Start, animated: true)
      
    }
    //create action move to gameplay view controller
     
    @IBAction func ActionBtn(_ sender: Any) {
        let Start = storyboard?.instantiateViewController(identifier: "GamePlayViewController") as! GamePlayViewController
        Start.modalPresentationStyle = .fullScreen
               present(Start, animated: true)
        
    }
    /*
    @IBAction func btnhome(_ sender: Any) {
        let Start = storyboard?.instantiateViewController(identifier: "FirstViewController") as! FirstViewController
        Start.modalPresentationStyle = .fullScreen
               present(Start, animated: true)
    }
     
    @IBAction func btnplay(_ sender: Any) {
        let Start = storyboard?.instantiateViewController(identifier: "PlayViewController") as! PlayViewController
        Start.modalPresentationStyle = .fullScreen
               present(Start, animated: true)
    }
   
     
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
